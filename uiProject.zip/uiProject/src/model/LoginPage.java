package model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Controller.PageForward;

public class LoginPage implements PageModel{
	private int code;
	
	public LoginPage(int code) {
		// TODO Auto-generated constructor stub
		this.code=code;
	}
	// 1 == ������ ����
	// 2 == ���
	// 3 == ��
	
	@Override
	public PageForward execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		if(code==1) {
			return new PageForward("login/loginform",false);
		}else if(code==2){
			return new PageForward("estate/addestate",false);
		}else if(code==3) {
			return new PageForward("estate/estate_one",false);
		}
		return new PageForward("estate/estate",false);
	}

}
